class Post < ApplicationRecord
  has_many :comments, dependent: :destroy
  
  validates :title, presence: true, length: { maximum: 100 }
  validates :content, presence: true, length: { minimum: 140 }
  validates :author, presence: true, format: { with: URI::MailTo::EMAIL_REGEXP, message: "must be a valid email" }
  
  enum published: { unpublished: 0, published: 1 }
end
