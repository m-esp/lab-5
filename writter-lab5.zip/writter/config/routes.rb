Rails.application.routes.draw do
  resources :posts, only: [:index, :show]
  resources :users, only: [:show, :edit, :update]
  get '/hashtag/:name', to: 'hashtags#show', as: :hashtag
  get 'about', to: 'pages#about', as: 'about'
  get 'contact', to: 'pages#contact', as: 'contact'
  get 'profile/edit', to: 'profiles#edit', as: 'edit_profile'


  root 'posts#index'
end
