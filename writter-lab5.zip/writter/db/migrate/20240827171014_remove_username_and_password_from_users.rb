class RemoveUsernameAndPasswordFromUsers < ActiveRecord::Migration[7.2]
  def change
    remove_column :users, :username, :string
    remove_column :users, :encrypted_password, :string
  end
end
