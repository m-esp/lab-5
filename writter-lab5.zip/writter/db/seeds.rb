# db/seeds.rb

# Clear existing records in the correct order
Comment.delete_all
Hashtag.delete_all
Post.delete_all
User.delete_all

# Reset primary key sequence if using PostgreSQL
ActiveRecord::Base.connection.reset_pk_sequence!('comments')
ActiveRecord::Base.connection.reset_pk_sequence!('hashtags')
ActiveRecord::Base.connection.reset_pk_sequence!('posts')
ActiveRecord::Base.connection.reset_pk_sequence!('users')

# Create Users
10.times do |i|
  User.create!(
    email: "user#{i+1}@example.com",
    first_name: "FirstName#{i+1}",
    last_name: "LastName#{i+1}"
  )
end

# Create Posts
10.times do |i|
  Post.create!(
    title: "Post Title #{i+1}",
    content: "This is some unique content for post number #{i+1}. " * 10 + "This ensures that the content meets the 140 characters requirement.",
    published: i.even? ? 1 : 0,
    author: User.all.sample.email 
  )
end

# Create Hashtags
10. times do |i|
  Hashtag.create!(
    name: "Hashtag#{i+1}",
    post_id: Post.all.sample.id 
  )
end 

# Create Comments
10.times do |i|
  Comment.create!(
    content: "This is a comment for post number #{i+1}.",
    author: User.all.sample.email, 
    post_id: Post.all.sample.id 
  )
end
